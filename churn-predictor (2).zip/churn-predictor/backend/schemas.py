from pydantic import BaseModel


class DBConnectRequest(BaseModel):
    connection_string: str
    query: str


class ConnectResponse(BaseModel):
    status: str
    accounts_loaded: int
    source: str
