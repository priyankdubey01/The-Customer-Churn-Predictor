"""
Data source abstraction.

The scoring engine only cares about one shape of data: a DataFrame of raw
behavior events with columns [account_id, account_name, event_date, event_type].
This module is responsible for getting that shape from wherever the
customer's data actually lives.

Two sources are supported out of the box:
  - CSVSource: an uploaded file (what the dashboard uses by default)
  - DatabaseSource: a live SQL database, connected via SQLAlchemy

Adding a new source (e.g. a REST API, a warehouse like Snowflake/BigQuery,
or a webhook stream) means writing one more class with a `load()` method
that returns a DataFrame in this shape -- nothing else in the app changes.
"""

from __future__ import annotations

import io
import pandas as pd
from sqlalchemy import create_engine, text

REQUIRED_COLUMNS = {"account_id", "account_name", "event_date", "event_type"}


def _validate(df: pd.DataFrame) -> pd.DataFrame:
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(
            f"Data is missing required column(s): {', '.join(sorted(missing))}. "
            f"Expected columns: {', '.join(sorted(REQUIRED_COLUMNS))}"
        )
    df = df.copy()
    df["event_date"] = pd.to_datetime(df["event_date"], errors="coerce")
    if df["event_date"].isna().any():
        raise ValueError("Some rows have an event_date that could not be parsed.")
    return df[list(REQUIRED_COLUMNS)]


class CSVSource:
    """Loads events from an in-memory CSV upload (bytes)."""

    def load(self, file_bytes: bytes) -> pd.DataFrame:
        df = pd.read_csv(io.BytesIO(file_bytes))
        return _validate(df)


class DatabaseSource:
    """
    Loads events from a live SQL database via SQLAlchemy.

    Works with any DB SQLAlchemy supports (Postgres, MySQL, SQL Server,
    SQLite, Snowflake with the right dialect package installed). The
    caller supplies the connection string and a query that returns rows
    already shaped as [account_id, account_name, event_date, event_type] --
    that mapping is where each customer's actual schema gets adapted, so
    this class stays schema-agnostic.

    Example connection strings:
        postgresql+psycopg2://user:pass@host:5432/dbname
        mysql+pymysql://user:pass@host:3306/dbname
    """

    def __init__(self, connection_string: str):
        # pool_pre_ping avoids handing back dead connections from the pool
        self.engine = create_engine(connection_string, pool_pre_ping=True)

    def test_connection(self) -> None:
        with self.engine.connect() as conn:
            conn.execute(text("SELECT 1"))

    def load(self, query: str) -> pd.DataFrame:
        with self.engine.connect() as conn:
            df = pd.read_sql(text(query), conn)
        return _validate(df)
