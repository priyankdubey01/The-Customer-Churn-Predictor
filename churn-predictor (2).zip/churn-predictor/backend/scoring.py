"""
Rule-based churn risk scoring engine.

Design goals:
- Explainable: every point on the score maps to a named, human-readable reason.
- Deterministic: no black-box model, easy for a CS team to trust and tune.
- Cheap to run: pure pandas aggregation, no training step, works on day one
  with zero historical labels (a real advantage over ML for a new dataset).

Input contract
---------------
A pandas DataFrame of raw behavior events with columns:
    account_id     (str)
    account_name   (str)
    event_date     (datetime-like)
    event_type     (str) one of: "login", "feature_use", "support_ticket", "error"

The engine aggregates events into 30-day windows and applies weighted rules.
"""

from __future__ import annotations

import pandas as pd
from dataclasses import dataclass, field
from datetime import timedelta


# ---------------------------------------------------------------------------
# Tunable rule weights. Keeping these as a plain dict (rather than burying
# them in code) makes it trivial for a CS ops team to retune without reading
# the scoring logic itself.
# ---------------------------------------------------------------------------
RULES = {
    "no_activity_30d": {
        "points": 35,
        "label": "No activity at all in the last 30 days",
    },
    "login_drop_severe": {
        "points": 25,
        "label": "Logins dropped more than 50% vs. the prior 30 days",
    },
    "login_drop_moderate": {
        "points": 12,
        "label": "Logins dropped 20-50% vs. the prior 30 days",
    },
    "feature_drop_severe": {
        "points": 20,
        "label": "Feature usage dropped more than 50% vs. the prior 30 days",
    },
    "feature_drop_moderate": {
        "points": 10,
        "label": "Feature usage dropped 20-50% vs. the prior 30 days",
    },
    "long_inactivity": {
        "points": 20,
        "label": "No login in over 14 days",
    },
    "short_inactivity": {
        "points": 10,
        "label": "No login in over 7 days",
    },
    "support_spike": {
        "points": 15,
        "label": "3 or more support tickets in the last 30 days",
    },
    "support_present": {
        "points": 6,
        "label": "At least one support ticket in the last 30 days",
    },
    "error_spike": {
        "points": 10,
        "label": "More than 5 errors logged in the last 30 days",
    },
}

TIER_THRESHOLDS = {
    "high": 60,
    "medium": 30,
    # anything below "medium" is "low"
}


@dataclass
class AccountScore:
    account_id: str
    account_name: str
    score: int
    tier: str
    factors: list = field(default_factory=list)  # list of {code, label, points}
    logins_last_30d: int = 0
    logins_prior_30d: int = 0
    feature_uses_last_30d: int = 0
    feature_uses_prior_30d: int = 0
    support_tickets_last_30d: int = 0
    errors_last_30d: int = 0
    days_since_last_login: int | None = None
    last_event_date: str | None = None
    daily_activity: list = field(default_factory=list)  # for sparkline: [{date, count}]

    def to_dict(self):
        return {
            "account_id": self.account_id,
            "account_name": self.account_name,
            "score": self.score,
            "tier": self.tier,
            "factors": self.factors,
            "logins_last_30d": self.logins_last_30d,
            "logins_prior_30d": self.logins_prior_30d,
            "feature_uses_last_30d": self.feature_uses_last_30d,
            "feature_uses_prior_30d": self.feature_uses_prior_30d,
            "support_tickets_last_30d": self.support_tickets_last_30d,
            "errors_last_30d": self.errors_last_30d,
            "days_since_last_login": self.days_since_last_login,
            "last_event_date": self.last_event_date,
            "daily_activity": self.daily_activity,
        }


def _tier_for_score(score: int) -> str:
    if score >= TIER_THRESHOLDS["high"]:
        return "high"
    if score >= TIER_THRESHOLDS["medium"]:
        return "medium"
    return "low"


def _pct_drop(prior: int, last: int) -> float | None:
    """Percent drop from prior window to last window. None if prior was 0 (no baseline)."""
    if prior == 0:
        return None
    return (prior - last) / prior


def score_accounts(events: pd.DataFrame, as_of: pd.Timestamp | None = None) -> list[AccountScore]:
    """
    Compute a risk score + explanation list for every account in `events`.

    `as_of` lets you pin "today" to the latest event date in the dataset
    (useful for historical/demo data) instead of the real wall-clock date.
    """
    if events.empty:
        return []

    events = events.copy()
    events["event_date"] = pd.to_datetime(events["event_date"])

    if as_of is None:
        as_of = events["event_date"].max()

    window_last = as_of - timedelta(days=30)
    window_prior_start = as_of - timedelta(days=60)

    results: list[AccountScore] = []

    for account_id, grp in events.groupby("account_id"):
        account_name = grp["account_name"].iloc[0]

        last_30 = grp[grp["event_date"] > window_last]
        prior_30 = grp[(grp["event_date"] > window_prior_start) & (grp["event_date"] <= window_last)]

        logins_last = int((last_30["event_type"] == "login").sum())
        logins_prior = int((prior_30["event_type"] == "login").sum())
        feat_last = int((last_30["event_type"] == "feature_use").sum())
        feat_prior = int((prior_30["event_type"] == "feature_use").sum())
        tickets_last = int((last_30["event_type"] == "support_ticket").sum())
        errors_last = int((last_30["event_type"] == "error").sum())

        last_login_dates = grp[grp["event_type"] == "login"]["event_date"]
        days_since_login = (as_of - last_login_dates.max()).days if not last_login_dates.empty else None
        last_event_date = grp["event_date"].max()

        factors = []
        score = 0

        def add(code):
            nonlocal score
            rule = RULES[code]
            score += rule["points"]
            factors.append({"code": code, "label": rule["label"], "points": rule["points"]})

        total_activity_last_30 = len(last_30)

        # Rule: total silence
        if total_activity_last_30 == 0:
            add("no_activity_30d")
        else:
            # Login trend (only meaningful if there was a prior baseline)
            login_drop = _pct_drop(logins_prior, logins_last)
            if login_drop is not None:
                if login_drop > 0.5:
                    add("login_drop_severe")
                elif login_drop > 0.2:
                    add("login_drop_moderate")

            # Feature usage trend
            feat_drop = _pct_drop(feat_prior, feat_last)
            if feat_drop is not None:
                if feat_drop > 0.5:
                    add("feature_drop_severe")
                elif feat_drop > 0.2:
                    add("feature_drop_moderate")

        # Inactivity streak (independent of the 30-day window above)
        if days_since_login is not None:
            if days_since_login > 14:
                add("long_inactivity")
            elif days_since_login > 7:
                add("short_inactivity")

        # Support signal
        if tickets_last >= 3:
            add("support_spike")
        elif tickets_last >= 1:
            add("support_present")

        # Error signal
        if errors_last > 5:
            add("error_spike")

        score = min(score, 100)

        # Build a simple daily activity series for the trailing 30 days (sparkline fuel)
        daily = (
            last_30.groupby(last_30["event_date"].dt.date).size().reindex(
                pd.date_range(window_last.date(), as_of.date(), freq="D").date, fill_value=0
            )
        )
        daily_activity = [{"date": str(d), "count": int(c)} for d, c in daily.items()]

        results.append(
            AccountScore(
                account_id=str(account_id),
                account_name=str(account_name),
                score=score,
                tier=_tier_for_score(score),
                factors=sorted(factors, key=lambda f: -f["points"]),
                logins_last_30d=logins_last,
                logins_prior_30d=logins_prior,
                feature_uses_last_30d=feat_last,
                feature_uses_prior_30d=feat_prior,
                support_tickets_last_30d=tickets_last,
                errors_last_30d=errors_last,
                days_since_last_login=days_since_login,
                last_event_date=str(last_event_date.date()) if pd.notna(last_event_date) else None,
                daily_activity=daily_activity,
            )
        )

    results.sort(key=lambda r: -r.score)
    return results
