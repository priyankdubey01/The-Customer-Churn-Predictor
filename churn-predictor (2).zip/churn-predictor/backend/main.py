"""
Customer Churn Predictor -- backend.

Run with:
    uvicorn main:app --reload --port 8000

Then open frontend/index.html (or hit http://localhost:8000/ if serving
the static file, see bottom of this file).
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from data_sources import CSVSource, DatabaseSource
from schemas import DBConnectRequest, ConnectResponse
from scoring import score_accounts

app = FastAPI(title="Customer Churn Predictor")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # demo-friendly; lock this down to your real frontend origin in production
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- In-memory app state ----------------------------------------------------
# A real deployment would put this behind a proper datastore / cache keyed by
# workspace, but a single in-memory slot is enough for a demo or single-tenant
# instance and keeps the scoring hot-reloadable without a DB round trip.
STATE = {
    "events": None,  # pandas DataFrame in the [account_id, account_name, event_date, event_type] shape
    "source": None,  # "csv" | "database"
}


def _require_data():
    if STATE["events"] is None:
        raise HTTPException(status_code=400, detail="No data loaded yet. Upload a CSV or connect a database first.")
    return STATE["events"]


@app.post("/api/upload", response_model=ConnectResponse)
async def upload_csv(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="Please upload a .csv file.")
    contents = await file.read()
    try:
        df = CSVSource().load(contents)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    STATE["events"] = df
    STATE["source"] = "csv"
    return ConnectResponse(
        status="ok",
        accounts_loaded=df["account_id"].nunique(),
        source="csv",
    )


@app.post("/api/connect-db", response_model=ConnectResponse)
def connect_db(req: DBConnectRequest):
    try:
        source = DatabaseSource(req.connection_string)
        source.test_connection()
        df = source.load(req.query)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        # Covers connection errors, bad SQL, missing DB driver, etc.
        raise HTTPException(status_code=400, detail=f"Could not connect or query: {e}")

    STATE["events"] = df
    STATE["source"] = "database"
    return ConnectResponse(
        status="ok",
        accounts_loaded=df["account_id"].nunique(),
        source="database",
    )


@app.get("/api/summary")
def get_summary():
    df = _require_data()
    scored = score_accounts(df)
    counts = {"high": 0, "medium": 0, "low": 0}
    for s in scored:
        counts[s.tier] += 1
    avg_score = round(sum(s.score for s in scored) / len(scored), 1) if scored else 0
    return {
        "total_accounts": len(scored),
        "high_risk": counts["high"],
        "medium_risk": counts["medium"],
        "low_risk": counts["low"],
        "avg_score": avg_score,
        "source": STATE["source"],
    }


@app.get("/api/accounts")
def list_accounts(tier: str | None = None):
    df = _require_data()
    scored = score_accounts(df)
    if tier:
        scored = [s for s in scored if s.tier == tier]
    return [s.to_dict() for s in scored]


@app.get("/api/accounts/{account_id}")
def get_account(account_id: str):
    df = _require_data()
    scored = score_accounts(df)
    for s in scored:
        if s.account_id == account_id:
            return s.to_dict()
    raise HTTPException(status_code=404, detail="Account not found.")


@app.post("/api/reset")
def reset():
    STATE["events"] = None
    STATE["source"] = None
    return {"status": "ok"}


# --- Serve the frontend as static files, so the whole app is one process ---
frontend_dir = Path(__file__).parent.parent / "frontend"
if frontend_dir.exists():
    app.mount("/static", StaticFiles(directory=str(frontend_dir)), name="static")

    @app.get("/")
    def index():
        return FileResponse(str(frontend_dir / "index.html"))
