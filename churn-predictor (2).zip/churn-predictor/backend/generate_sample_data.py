"""
Generates synthetic behavior-log data so the dashboard can be demoed without
a real customer dataset. Produces a mix of healthy, cooling-off, and clearly
churning accounts so every risk tier shows up.

Run:
    python generate_sample_data.py
"""

import random
from datetime import timedelta, date

import pandas as pd

random.seed(42)
TODAY = date(2026, 7, 1)

ACCOUNTS = [
    ("acc_001", "Northwind Traders", "healthy"),
    ("acc_002", "Contoso Logistics", "healthy"),
    ("acc_003", "Globex Analytics", "cooling"),
    ("acc_004", "Initech Robotics", "cooling"),
    ("acc_005", "Umbrella Retail", "churning"),
    ("acc_006", "Wayne Manufacturing", "churning"),
    ("acc_007", "Stark Cloud Services", "healthy"),
    ("acc_008", "Wonka Foods Digital", "silent"),
    ("acc_009", "Hooli Data Co", "cooling"),
    ("acc_010", "Aperture Testing Inc", "churning"),
    ("acc_011", "Soylent Ventures", "healthy"),
    ("acc_012", "Massive Dynamic", "silent"),
]


def gen_events_for_account(account_id, name, profile):
    events = []

    def add(days_ago, event_type, count=1):
        d = TODAY - timedelta(days=days_ago)
        for _ in range(count):
            events.append(
                {"account_id": account_id, "account_name": name, "event_date": d, "event_type": event_type}
            )

    if profile == "healthy":
        # steady logins + feature use over 60 days, low support load
        for day in range(60):
            if random.random() < 0.7:
                add(day, "login", random.randint(1, 2))
            if random.random() < 0.6:
                add(day, "feature_use", random.randint(1, 3))
        if random.random() < 0.3:
            add(random.randint(0, 20), "support_ticket")

    elif profile == "cooling":
        # active 30-60 days ago, tapering off in the last 30
        for day in range(30, 60):
            if random.random() < 0.7:
                add(day, "login", random.randint(1, 2))
            if random.random() < 0.6:
                add(day, "feature_use", random.randint(1, 2))
        for day in range(0, 30):
            if random.random() < 0.25:
                add(day, "login")
            if random.random() < 0.15:
                add(day, "feature_use")
        add(random.randint(0, 15), "support_ticket", random.randint(1, 2))

    elif profile == "churning":
        # healthy 30-60 days ago, then a sharp cliff, with a support spike and errors
        for day in range(30, 60):
            if random.random() < 0.8:
                add(day, "login", random.randint(1, 2))
            if random.random() < 0.7:
                add(day, "feature_use", random.randint(1, 3))
        # cliff: only a couple of logins right at the start of the last 30d window
        add(28, "login")
        add(25, "login")
        add(random.randint(0, 10), "support_ticket", random.randint(3, 4))
        add(random.randint(0, 20), "error", random.randint(4, 7))

    elif profile == "silent":
        # was active 45-60 days ago, total silence since -- no baseline in last 30d
        for day in range(45, 60):
            if random.random() < 0.7:
                add(day, "login")
            if random.random() < 0.6:
                add(day, "feature_use")
        # nothing at all in the last 30 days

    return events


def main():
    all_events = []
    for account_id, name, profile in ACCOUNTS:
        all_events.extend(gen_events_for_account(account_id, name, profile))

    df = pd.DataFrame(all_events).sort_values(["account_id", "event_date"])
    out_path = "sample_data/behavior_logs.csv"
    df.to_csv(out_path, index=False)
    print(f"Wrote {len(df)} events for {len(ACCOUNTS)} accounts to {out_path}")


if __name__ == "__main__":
    main()
