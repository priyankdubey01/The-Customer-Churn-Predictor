# Signal — Customer Churn Predictor

A micro-SaaS dashboard that reads customer behavior logs and flags at-risk
accounts for a customer success team, before they cancel.

Scoring is **rule-based, not ML** — every point on an account's risk score
maps to a named, human-readable reason (e.g. "Logins dropped more than 50%").
That's a deliberate choice for a v1: no training data or labeled churn
history required, a CS team can trust and tune it immediately, and every
flagged account comes with an explanation instead of a black-box number.

## What's included

```
churn-predictor/
├── backend/
│   ├── main.py                  FastAPI app (upload, DB connect, scoring endpoints)
│   ├── scoring.py                Rule-based risk scoring engine
│   ├── data_sources.py           CSV + live-database data source abstraction
│   ├── schemas.py                Request/response models
│   ├── generate_sample_data.py   Synthetic demo data generator
│   ├── sample_data/behavior_logs.csv
│   └── requirements.txt
├── frontend/
│   └── index.html                Single-page dashboard (no build step)
└── README.md
```

## Quickstart

```bash
cd backend
pip install -r requirements.txt
python generate_sample_data.py     # optional — regenerates the demo CSV
uvicorn main:app --reload --port 8000
```

Open **http://localhost:8000** — FastAPI serves the dashboard directly, so
there's nothing else to run. Upload `backend/sample_data/behavior_logs.csv`
to see it working immediately with a mix of healthy, cooling-off, and
churning demo accounts.

## Data format

The engine expects raw behavior events, not pre-aggregated stats — it does
the aggregation itself so a CS team can hand it a straightforward event
export:

| column         | type   | example                     |
|----------------|--------|------------------------------|
| `account_id`   | string | `acc_005`                   |
| `account_name` | string | `Umbrella Retail`            |
| `event_date`   | date   | `2026-06-24`                 |
| `event_type`   | string | `login`, `feature_use`, `support_ticket`, `error` |

Any additional event types are ignored by the current rules but pass
through the pipeline harmlessly — new rules can key off them later.

## Connecting a live database instead of CSV

Click **Connect live database** in the dashboard and provide:
1. A SQLAlchemy connection string, e.g. `postgresql+psycopg2://user:pass@host:5432/dbname`
2. A SQL query that returns rows shaped as the table above

That mapping step — writing the query — is where each customer's actual
schema gets adapted to what the scoring engine expects, so the engine
itself stays schema-agnostic. You'll need the matching DB driver installed
(`pip install psycopg2-binary` for Postgres, `pymysql` for MySQL, etc.).

## The scoring rules

Defined in `backend/scoring.py` as a plain dict (`RULES`) so a CS ops team
can retune point values without touching the aggregation logic:

| Signal | Points |
|---|---|
| No activity at all in the last 30 days | 35 |
| Logins dropped >50% vs. prior 30 days | 25 |
| Logins dropped 20–50% vs. prior 30 days | 12 |
| Feature usage dropped >50% vs. prior 30 days | 20 |
| Feature usage dropped 20–50% vs. prior 30 days | 10 |
| No login in over 14 days | 20 |
| No login in over 7 days | 10 |
| 3+ support tickets in last 30 days | 15 |
| 1+ support ticket in last 30 days | 6 |
| More than 5 errors in last 30 days | 10 |

Scores cap at 100. Tiers: **high** ≥ 60, **medium** 30–59, **low** < 30.

## API reference

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/api/upload` | Upload a CSV of events |
| `POST` | `/api/connect-db` | Connect a live DB (`{connection_string, query}`) |
| `GET`  | `/api/summary` | Account counts by tier + average score |
| `GET`  | `/api/accounts?tier=high` | List scored accounts, optionally filtered |
| `GET`  | `/api/accounts/{id}` | Full detail + risk factor breakdown for one account |
| `POST` | `/api/reset` | Clear loaded data |

## Extending this into a real product

This is a solid v1 core, not a finished SaaS. Natural next steps, roughly
in order of impact:

- **Persistence**: swap the in-memory `STATE` dict in `main.py` for a real
  database (Postgres) so data survives restarts and supports multiple
  customer workspaces.
- **Auth & multi-tenancy**: the current app is single-tenant by design.
- **Scheduled refresh**: for the live-DB path, run scoring on a schedule
  (e.g. hourly via a cron job or Celery task) instead of only on manual connect.
- **Alerting**: push high-risk accounts to Slack/email instead of requiring
  someone to check the dashboard.
- **Calibration against real outcomes**: once you have actual churn labels,
  you can validate the rule weights (or eventually blend in a learned model)
  against ground truth instead of tuning them by intuition.
